package com.lithidsw.findex.info;

public class DirPickerInfo {
    public String name;
    public String dir;
}
