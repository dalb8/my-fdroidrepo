package com.lithidsw.findex.widget;

import java.io.Serializable;

public class WidgetInfo implements Serializable {
    public int id;
    public int position;
    public String value;
}
